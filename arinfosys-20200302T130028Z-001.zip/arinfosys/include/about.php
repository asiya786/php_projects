  <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>About Us</h3>
          <p>arinfosys delivers high-end IT solutions to businesses. We offer best class web solutions for your business that helps you to succeed in your ventures.

Our team members have worked with various successful startups and large-scale enterprise to produce best IT solutions for various industries. We develop and present new ideas, concepts, solutions and approaches for client success. We always focus on critical information and leave out irrelevant or unnecessary details and maintains a high level of professionalism. We believe in dedicated involvement to provide post-implementation support.</p>
        </header>

        <div class="row about-cols">

          <div class="col-md-4 wow fadeInUp">
            <div class="about-col">
              <div class="img">
                <img src="img/about-mission.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Mission</a></h2>
              <p>
                To implement ingenuity & innovative ideas.
Maintaining long lasting customer relationship.
Bench marking qualitative & ethical standerds.
 Sincere committed and professional team work.
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.1s">
            <div class="about-col">
              <div class="img">
                <img src="img/about-plan.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-list-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Plan</a></h2>
              <p>
                arinfosys is a proficiently managed web based company 
arinfosis delivers high-end IT solutions to businesses. We offer best class web solutions for your business that helps you to succeed in your ventures..
              </p>
            </div>
          </div>

          <div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
            <div class="about-col">
              <div class="img">
                <img src="img/about-vision.jpg" alt="" class="img-fluid">
                <div class="icon"><i class="ion-ios-eye-outline"></i></div>
              </div>
              <h2 class="title"><a href="#">Our Vision</a></h2>
              <p>
                We develop and present new ideas, concepts, solutions and approaches for client success. We always focus on critical information and leave out irrelevant or unnecessary details and maintains a high level of professionalism.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>