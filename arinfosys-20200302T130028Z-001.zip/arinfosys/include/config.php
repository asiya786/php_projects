<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "arinfosys";
$conn = mysqli_connect($hostname,$username,$password,$dbname); 



?>