 <section id="featured-services">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 box">
            <i class="ion-ios-bookmarks-outline"></i>
            <h4 class="title"><a href="">Stisfactiont</a></h4>
            <p class="description">To be one of the best in our areas of business through commitment to excel and succeed with total customer satisfaction. arinfosys provides the bespoke website security services that help your website to be up and running 24*7.</p>
          </div>

          <div class="col-lg-4 box box-bg">
            <i class="ion-ios-stopwatch-outline"></i>
            <h4 class="title"><a href="">Trust</a></h4>
            <p class="description">The website depicts your company on the internet and us at arinfosys proudly say that our great reputation and proven trust is the best asset for us. We provide professional, creative, fast turnaround time,</p>
          </div>

          <div class="col-lg-4 box">
            <i class="ion-ios-heart-outline"></i>
            <h4 class="title"><a href="">Perfection</a></h4>
            <p class="description">An excellent service provider, we were looking for quality SEO and SMO services. Luckily we found arinfosys with the highly expert team and good client servicing. It�s a basket full of services, will recommend others for sure</p>
          </div>

        </div>
      </div>
    </section>