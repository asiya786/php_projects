  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>arinfosys</h3>
            <p>arinfosis delivers high-end IT solutions to businesses. We offer best class web solutions for your business that helps you to succeed in your ventures.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="ion-ios-arrow-right"></i> <a href="#intro">Home</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#about">About us</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#services">Services</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
            16/26,Thimmaiah Road,Jeevanahalli,Park Road,Banglore-05. <br>
              <strong>Phone:</strong>9353600215<br>
              <strong>Email:</strong> arinfosys@.com<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>
You only have a moment to capture the attention of your visiting audience, so make a good impression by having a winning formula that will help your clients find what they are looking for quickly and easily.</p>
			<?php
			include("config.php");
			if(isset($_POST["done"])){
			$email = $_POST["email"];
			$query = "INSERT INTO `subscribe`(`id`, `email`) VALUES (NULL,'$email')"; 
			$q = mysqli_query($conn,$query);
			
			}
			
			?>
            <form action="" method="POST">
              <input type="email" name="email"><button type="submit" name="done" class="btn btn-success">Sub</button>
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>Epetg</strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
        Designed by <a href="#">arinfosys</a>
      </div>
    </div>
  </footer>