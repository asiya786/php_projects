 <section id="services">
      <div class="container">

        <header class="section-header wow fadeInUp">
          <h3>Services</h3>
          <p>Staying ahead in this competitive world is a tough task and arinfosys, makes it comfortable and ease to you to be at the top with its regular updates. We offer Website security service that keeps a continuous monitor on hacker activity, malware detection and audits</p>
        </header>

        <div class="row">

          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-analytics-outline"></i></div>
            <h4 class="title"><a href="">Website Design</a></h4>
            <p class="description">We work to make you look good online. A good web design helps duplicate your time and can increase your turnover without any extra effort. arinfosys offers you unique web design with interactive UI that have better user experience, stand out to give you an edge over competitors, lesser bounce rates, less loading time and</p>
          </div>
          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-bookmarks-outline"></i></div>
            <h4 class="title"><a href="">Website Application Development</a></h4>
            <p class="description">The website depicts your company on the internet and us at Nextwebi proudly say that our great reputation and proven trust is the best asset for us. We provide professional, creative, fast turnaround time,</p>
          </div>
          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-paper-outline"></i></div>
            <h4 class="title"><a href="">Branding & Strategy</a></h4>
            <p class="description">We just not only focus on graphic design but at your brand�s overall persona, values and device ways in which the website branding can accentuate it's online performance.</p>
          </div>
          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-speedometer-outline"></i></div>
            <h4 class="title"><a href="">Digital Marketing</a></h4>
            <p class="description">At arinfosys we provide design solutions for brands that wish to connect with a varied larger audience in the digital domain. Digital marketing in its various ways maximize brand�s online and offline presence with eye-catching visuals to amazing content</p>
          </div>
          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-barcode-outline"></i></div>
            <h4 class="title"><a href="">API Integrations</a></h4>
            <p class="description">We have an extensive experience in 3rd party API integrations across the domain which helps our customers to integrate the application with multiple systems. Contact us to discuss more with our expert.</p>
          </div>
          <div class="col-lg-4 col-md-6 box wow bounceInUp" data-wow-delay="0.1s" data-wow-duration="1.4s">
            <div class="icon"><i class="ion-ios-people-outline"></i></div>
            <h4 class="title"><a href="">Search Engine Optimization</a></h4>
            <p class="description">Amidst IT revolution, the internet is playing a pivotal role in success and failure of a business. In fact, every small, medium and large business houses are trying their best to seize the oceanic opportunity that the internet has given to them</p>
          </div>

        </div>

      </div>
    </section>