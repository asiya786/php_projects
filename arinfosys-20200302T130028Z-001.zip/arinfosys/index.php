
<?php include("include/headlink.php"); ?>


<body>

  <!--==========================
    Header
  ============================-->
    <?php include("include/header.php"); ?>
<!-- #header -->

  <!--==========================
    Intro Section
  ============================-->
     <?php include("include/intro.php"); ?>
<!-- #intro -->

  <main id="main">

    <!--==========================
      Featured Services Section
    ============================-->
      <?php include("include/feature_service.php");?>
   <!-- #featured-services -->

    <!--==========================
      About Us Section
    ============================-->
  <!-- #about -->
<?php include("include/about.php");?>
    <!--==========================
      Services Section
    ============================-->
      <?php include("include/services.php");?>
   <!-- #services -->

    <!--==========================
      Call To Action Section
    ============================-->
      
      <?php include("include/call.php");?>
  <!-- #call-to-action -->

    <!--==========================
      Skills Section
    ============================-->
<?php include("include/skill.php");?>
      
      <!-- # Skills -->

    <!--==========================
      Facts Section
    ============================-->
       <?php include("include/fact.php");?>
<!-- #facts -->

    <!--==========================
      Portfolio Section
    ============================-->
      <?php include("include/portfolio.php");?>
 <!-- #portfolio -->

    <!--==========================
      Clients Section
    ============================-->
<!-- #clients -->
<?php include("include/client.php");?>
    <!--==========================
     testimonials Section
    ============================-->
           <?php include("include/testimonial.php");?>
<!-- #testimonials -->

    <!--==========================
      Team Section
    ============================-->
        <?php include("include/team.php");?>
  <!-- #team -->

    <!--==========================
      Contact Section
    ============================-->
       <?php include("include/contact.php");?>
<!-- #contact -->

  </main>

  <!--==========================
    Footer
  ============================-->
    <?php include("include/footer.php");?>
<!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
